load sensorStructHouseA.mat
load actStructHouseA.mat
load senseandactLabelsHouseA.mat

 