load sensorStructHouseB.mat
load actStructHouseB.mat
load senseandactLabelsHouseB.mat

